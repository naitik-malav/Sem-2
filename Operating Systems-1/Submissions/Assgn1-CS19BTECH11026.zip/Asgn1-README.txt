Below are steps to execute program:

1. First open terminal and move on to directory where you have saved the source code.
2. For compilation of program, type below statement:
	gcc Asgn1-CS19BTECH11026.c -o ./test -pthread -lrt
3. after compilation, type:
	./test <command name>
4. then press enter and ElapsedTime will be printed on the screen.
5. Eg. for <command name> = bin, ls, df, cd
