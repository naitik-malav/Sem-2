#include <stdio.h>
#include <sys/mman.h>
#include <unistd.h>
#include <sys/time.h>
#include <fcntl.h>
#include <sys/wait.h>
double MicroSeconds = .000001;      //required to convert time into microseconds 

/* we have passed int argc and char *argv[] in main function to scan the process befor execultion */
int main(int argc,char *argv[])
{
    if(argv[1] == NULL)
    {
        /* if you didn't enter any command and directly executes the executable file */
        printf("Please enter some commands \n");    
        return -1;  //so to terminate program we are returning 1
    }
    int SharedMemory_size = 64; //locating size of shared memory which is equal to 64 in our case
    char *Memory = "SHM";

    /*pointer to shared memory and file descriptor */
    int FileDescriptor;
    char *ptr_s; 

    /*current is an object to struct timeval, which contains two members: tv_sec and t_usec*/
    struct timeval current; 
    FileDescriptor = shm_open(Memory, O_CREAT|O_RDWR, 0666);    //formation of shared memory 
    ftruncate(FileDescriptor, SharedMemory_size);   //allocating memory to the shared memory by using ftruncate function

    ptr_s = (char*)mmap(0, SharedMemory_size, PROT_READ|PROT_WRITE, MAP_SHARED, FileDescriptor, 0); //mapping memory
    pid_t pid=fork(); //creating process using pid and fork() function call

    if (pid < 0) {
        // if suppose fork returns negative value, then there will be an error while creating child process
        fprintf(stderr,"fork() failure: pid<0\n");
        return -1;
    }

    /* whenever fork returns 0 then this pid is of the child process */
    else if (pid == 0) {   
        /* Acc to assignment, we have to get the timestamp using gettimeofday() function*/
        gettimeofday(&current, NULL);
        sprintf(ptr_s, "%ld %ld", current.tv_sec,current.tv_usec);
        //execlp("/bin/ping", "ping", NULL);
        execvp(argv[1],argv+1);     //it replace the process memory with program
        return 0;
    }

    else{
        wait(NULL);     // waiting for the child process to gets complete
        gettimeofday(&current, NULL);   // timestamping the process again
        int time1, time2;
        sscanf(ptr_s, "%d %d", &time1, &time2);
        double Time = current.tv_sec+current.tv_usec*MicroSeconds;
        Time = Time-time1-time2*MicroSeconds;   //elapsed time by the entered process
        printf("ElapsedTime: %lf\n",Time);
        shm_unlink(Memory);
    }
}